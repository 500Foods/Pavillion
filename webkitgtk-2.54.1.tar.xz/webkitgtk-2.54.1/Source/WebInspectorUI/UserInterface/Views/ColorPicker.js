/*
 * Copyright (C) 2013-2022 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. AND ITS CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE INC. OR ITS CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

WI.ColorPicker = class ColorPicker extends WI.Object
{
    constructor({preventChangingColorFormats, colorVariables, contrastInfo} = {})
    {
        super();

        this._preventChangingColorFormats = !!preventChangingColorFormats;
        this._contrastInfo = contrastInfo || null;

        this._colorSquare = new WI.ColorSquare(this, 200);
        if (this._contrastInfo?.contrastColor) {
            this._colorSquare.contrastColor = this._contrastInfo.contrastColor;
            this._colorSquare.isLargeText = !!this._contrastInfo.isLargeText;
        }

        this._hueSlider = new WI.Slider;
        this._hueSlider.delegate = this;
        this._hueSlider.element.classList.add("hue");

        this._opacitySlider = new WI.Slider;
        this._opacitySlider.delegate = this;
        this._opacitySlider.element.classList.add("opacity");

        this._colorInputs = [];
        this._colorInputsFormat = null;
        this._colorInputsHasAlpha = null;

        this._colorInputsContainerElement = document.createElement("div");
        this._colorInputsContainerElement.classList.add("color-inputs");
        this._colorInputsContainerElement.addEventListener("input", this._handleColorInputsContainerInput.bind(this));

        this._element = document.createElement("div");
        this._element.classList.add("color-picker");

        let wrapper = this._element.appendChild(document.createElement("div"));
        wrapper.className = "wrapper";
        wrapper.appendChild(this._colorSquare.element);
        wrapper.appendChild(this._hueSlider.element);
        wrapper.appendChild(this._opacitySlider.element);

        let colorInputsWrapperElement = this._element.appendChild(document.createElement("div"));
        colorInputsWrapperElement.classList.add("color-inputs-wrapper");

        if (!this._preventChangingColorFormats) {
            let formatOptionsElement = WI.ImageUtilities.useSVGSymbol("Images/Gear.svg", "format-options");
            formatOptionsElement.role = "button";
            WI.addMouseDownContextMenuHandlers(formatOptionsElement, this._populateFormatContextMenu.bind(this));
            colorInputsWrapperElement.appendChild(formatOptionsElement);
        }

        colorInputsWrapperElement.appendChild(this._colorInputsContainerElement);

        if (InspectorFrontendHost.canPickColorFromScreen()) {
            let pickColorElement = WI.ImageUtilities.useSVGSymbol("Images/Pipette.svg", "pick-color-from-screen", WI.UIString("Pick color from screen", "Color picker view tooltip for picking a color from the screen."));
            pickColorElement.role = "button";
            pickColorElement.addEventListener("click", async (event) => {
                pickColorElement.classList.add("active");
                let pickedColor = await WI.ColorPicker.pickColorFromScreen({
                    suggestedFormat: this.color.format,
                    suggestedGamut: this.color.gamut,
                    forceSuggestedFormatAndGamut: this._preventChangingColorFormats,
                });
                pickColorElement.classList.remove("active");

                if (!pickedColor)
                    return;

                this.color = pickedColor;
                this.dispatchEventToListeners(WI.ColorPicker.Event.ColorChanged, {color: this._color});
            });

            colorInputsWrapperElement.appendChild(pickColorElement);
        }

        this._contrastInfoElement = null;
        if (this._contrastInfo?.contrastColor)
            this._createContrastInfoSection();

        this._opacity = 0;
        this._opacityPattern = "url(Images/Checkers.svg)";

        this.color = WI.Color.fromString("white");

        if (colorVariables?.length) {
            let variableColorSwatchesContainer = this._element.appendChild(document.createElement("div"));
            variableColorSwatchesContainer.classList.add("variable-color-swatches");

            let swatchesTitle = variableColorSwatchesContainer.appendChild(document.createElement("h2"));
            swatchesTitle.textContent = WI.UIString("Variables", "Variables @ Color Picker", "Title of swatches section in Color Picker");

            let variableColorSwatchesListElement = variableColorSwatchesContainer.appendChild(document.createElement("ul"));
            let sortedColorVariables = WI.ColorPicker.sortColorVariables(colorVariables);

            for (let variable of sortedColorVariables) {
                let computedColor = WI.Color.fromString(variable.value)
                let swatch = new WI.InlineSwatch(WI.InlineSwatch.Type.Color, computedColor, {readOnly: true, tooltip: variable.name});
                swatch.element.addEventListener("click", (event) => {
                    this._updateColorForVariable(computedColor, variable.name);
                });
                variableColorSwatchesListElement.appendChild(document.createElement("li")).appendChild(swatch.element);
            }
        }

        this._dontUpdateColor = false;
    }

    // Static

    static async pickColorFromScreen({suggestedFormat, suggestedGamut, forceSuggestedFormatAndGamut} = {})
    {
        console.assert(InspectorFrontendHost.canPickColorFromScreen());

        // There is a brief moment where the frontend page remains interactable before the backend actually begins the
        // modal color picking mode. In order to avoid accidentally hovering an element and showing its highlight on the
        // page and not being able to hide the highlight while selecting a color, make the document inert so that even
        // immediate mouse movement doesn't accidentaly cause any highlighting to occur.
        document.body.inert = true;

        let pickedColorCSSString = null;
        try {
            pickedColorCSSString = await InspectorFrontendHost.pickColorFromScreen();
        } catch (error) {
            WI.reportInternalError(error);
        }

        document.body.inert = false;

        if (!pickedColorCSSString)
            return null;

        return WI.Color.fromStringBestMatchingSuggestedFormatAndGamut(pickedColorCSSString, {suggestedFormat, suggestedGamut, forceSuggestedFormatAndGamut});
    }

    static sortColorVariables(colorVariables)
    {
        const rotation = 2;
        const weights = [Math.E / 11.279, Math.E / 3.934, Math.E / 39.975];

        function visualAppeal(variable) {
            let color = WI.Color.fromString(variable.value);
            let [h, s, l] = color.hsl;

            let luminosity = Math.floor(color.rgb.reduce((total, component, i) => total + component * weights[i]));

            let [modifiedH, modifiedLuminosity, modifiedLight] = [h, luminosity, l].map((component) => Math.floor(component * rotation));

            if (modifiedH % 2 === 1) {
                modifiedLight = rotation - modifiedLight;
                luminosity = rotation - luminosity;
            }

            return {lightScore: modifiedLight, luminosityScore: luminosity, hueScore: modifiedH};
        }

        let colorVariableVisualAppealScores = new Map(colorVariables.map((variable) => [variable, visualAppeal(variable)]));

        return colorVariables.sort((variableA, variableB) => {
            let appealA = colorVariableVisualAppealScores.get(variableA);
            let appealB = colorVariableVisualAppealScores.get(variableB);
            return appealB.hueScore - appealA.hueScore || appealB.luminosityScore - appealA.luminosityScore || appealB.lightScore - appealA.lightScore;
        });
    }

    static addContextMenuFormatItems(contextMenu, color, formatChangedCallback)
    {
        let isColorOutsideSRGB = color.isOutsideSRGB();

        if (!isColorOutsideSRGB) {
            if (color.isKeyword() && color.format !== WI.Color.Format.Keyword) {
                contextMenu.appendItem(WI.UIString("Format: Keyword"), () => {
                    formatChangedCallback(WI.Color.Format.Keyword);
                });
            }

            let hexInfo = color.getNextValidHEXFormat();
            if (hexInfo) {
                contextMenu.appendItem(hexInfo.title, () => {
                    formatChangedCallback(hexInfo.format);
                });
            }

            if (color.simple && color.format !== WI.Color.Format.HSL) {
                contextMenu.appendItem(WI.UIString("Format: HSL"), () => {
                    formatChangedCallback(WI.Color.Format.HSL);
                });
            } else if (color.format !== WI.Color.Format.HSLA) {
                contextMenu.appendItem(WI.UIString("Format: HSLA"), () => {
                    formatChangedCallback(WI.Color.Format.HSLA);
                });
            }

            if (color.simple && color.format !== WI.Color.Format.RGB) {
                contextMenu.appendItem(WI.UIString("Format: RGB"), () => {
                    formatChangedCallback(WI.Color.Format.RGB);
                });
            } else if (color.format !== WI.Color.Format.RGBA) {
                contextMenu.appendItem(WI.UIString("Format: RGBA"), () => {
                    formatChangedCallback(WI.Color.Format.RGBA);
                });
            }

            if (color.format !== WI.Color.Format.ColorFunction) {
                contextMenu.appendItem(WI.UIString("Format: Color Function"), () => {
                    formatChangedCallback(WI.Color.Format.ColorFunction);
                });
            }

            contextMenu.appendSeparator();
        }
    }

    // Public

    get element() { return this._element; }
    get colorSquare() { return this._colorSquare; }

    set opacity(opacity)
    {
        if (opacity === this._opacity)
            return;

        this._opacity = opacity;
        this._colorSquare.opacity = opacity;
        this._updateColor();
    }

    get color()
    {
        return this._color;
    }

    set color(color)
    {
        console.assert(color instanceof WI.Color);

        this._dontUpdateColor = true;

        this._color = color;

        this._colorSquare.tintedColor = this._color;
        this._colorSquare.opacity = this._color.alpha;

        this._hueSlider.value = this._color.hsl[0] / 360;

        this._opacitySlider.value = this._color.alpha;
        this._updateOpacitySlider();

        this._showColorComponentInputs();
        this._updateColorGamut();
        this._updateContrastInfo();

        this._dontUpdateColor = false;
    }

    focus()
    {
        this._colorSquare.element.focus();
    }

    colorSquareColorDidChange(colorSquare)
    {
        this._updateColor();
        this._updateOpacitySlider();
    }

    sliderValueDidChange(slider, value)
    {
        if (slider === this._opacitySlider)
            this.opacity = value;
        else if (slider === this._hueSlider) {
            this._colorSquare.hue = value * 360;
            this._updateColor();
            this._updateOpacitySlider();
        }
    }

    // Private

    _updateColor()
    {
        if (this._dontUpdateColor)
            return;

        let opacity = Math.round(this._opacity * 100) / 100;

        let format = this._color.format;
        let gamut = this._color.gamut;
        let components = null;
        if (format === WI.Color.Format.HSL || format === WI.Color.Format.HSLA) {
            components = this._colorSquare.tintedColor.hsl.concat(opacity);
            if (opacity !== 1)
                format = WI.Color.Format.HSLA;
        } else if (format === WI.Color.Format.ColorFunction)
            components = this._colorSquare.tintedColor.normalizedRGB.concat(opacity);
        else {
            components = this._colorSquare.tintedColor.rgb.concat(opacity);
            if (opacity !== 1 && format === WI.Color.Format.RGB)
                format = WI.Color.Format.RGBA;
        }

        this._color = new WI.Color(format, components, gamut);

        this._showColorComponentInputs();

        this.dispatchEventToListeners(WI.ColorPicker.Event.ColorChanged, {color: this._color});

        this._updateColorGamut();
        this._updateContrastInfo();
    }

    _updateOpacitySlider()
    {
        let color = this._colorSquare.tintedColor;

        let rgb = color.format === WI.Color.Format.ColorFunction ? color.normalizedRGB : color.rgb;
        let gamut = color.gamut;
        let format = gamut === WI.Color.Gamut.DisplayP3 ? WI.Color.Format.ColorFunction : WI.Color.Format.RGBA;
        let opaque = new WI.Color(format, rgb.concat(1), gamut).toString();
        let transparent = new WI.Color(format, rgb.concat(0), gamut).toString();
        this._opacitySlider.element.style.setProperty("background-image", "linear-gradient(0deg, " + transparent + ", " + opaque + "), " + this._opacityPattern);
    }

    _updateColorGamut()
    {
        this._element.classList.toggle("gamut-p3", this._color.gamut === WI.Color.Gamut.DisplayP3);
    }

    _needsAlphaColorInput()
    {
        switch (this._color.format) {
        case WI.Color.Format.RGBA:
        case WI.Color.Format.HSLA:
        case WI.Color.Format.HEXAlpha:
        case WI.Color.Format.ShortHEXAlpha:
            return true;
        }
        return false;
    }

    _createColorInputsIfNeeded()
    {
        let hasAlpha = this._color.alpha !== 1;
        if ((this._color.format === this._colorInputsFormat) && (hasAlpha === this._colorInputsHasAlpha))
            return;

        this._colorInputsFormat = this._color.format;
        this._colorInputsHasAlpha = hasAlpha;

        this._colorInputs = [];
        this._colorInputsContainerElement.removeChildren();

        let createColorInput = (label, title, {max, step} = {}) => {
            let labelElement = this._colorInputsContainerElement.createChild("label");
            labelElement.title = title;
            labelElement.textContent = label;

            let numberInputElement = labelElement.createChild("input");
            numberInputElement.type = "number";
            numberInputElement.min = 0;
            numberInputElement.max = max;
            numberInputElement.step = step || 1;
            this._colorInputs.push(numberInputElement);
        };

        switch (this._color.format) {
        case WI.Color.Format.RGB:
        case WI.Color.Format.RGBA:
        case WI.Color.Format.HEX:
        case WI.Color.Format.ShortHEX:
        case WI.Color.Format.HEXAlpha:
        case WI.Color.Format.ShortHEXAlpha:
        case WI.Color.Format.Keyword:
            createColorInput("R", WI.UIString("Red", "Red @ Color Picker", "Label for red color component of CSS color."), {max: 255});
            createColorInput("G", WI.UIString("Green", "Green @ Color Picker", "Label for green color component of CSS color."), {max: 255});
            createColorInput("B", WI.UIString("Blue", "Blue @ Color Picker", "Label for blue color component of CSS color."), {max: 255});
            break;

        case WI.Color.Format.HSL:
        case WI.Color.Format.HSLA:
            createColorInput("H", WI.UIString("Hue", "Hue @ Color Picker", "Label for hue color component of CSS color."), {max: 360});
            createColorInput("S", WI.UIString("Saturation", "Saturation @ Color Picker", "Label for saturation color component of CSS color."), {max: 100});
            createColorInput("L", WI.UIString("Lightness", "Lightness @ Color Picker", "Label for lightness color component of CSS color."), {max: 100});
            break;

        case WI.Color.Format.ColorFunction:
            createColorInput("R", WI.UIString("Red", "Red @ Color Picker", "Label for red color component of CSS color."), {max: 1, step: 0.01});
            createColorInput("G", WI.UIString("Green", "Green @ Color Picker", "Label for green color component of CSS color."), {max: 1, step: 0.01});
            createColorInput("B", WI.UIString("Blue", "Blue @ Color Picker", "Label for blue color component of CSS color."), {max: 1, step: 0.01});
            break;

        default:
            console.error(`Unknown color format: ${this._color.format}`);
            return;
        }

        if (this._color.alpha !== 1 || this._needsAlphaColorInput())
            createColorInput("A", WI.UIString("Alpha", "Alpha @ Color Picker", "Label for alpha color component of CSS color."), {max: 1, step: 0.01});
    }

    _showColorComponentInputs()
    {
        this._createColorInputsIfNeeded();

        let components = [];
        switch (this._color.format) {
        case WI.Color.Format.RGB:
        case WI.Color.Format.RGBA:
        case WI.Color.Format.HEX:
        case WI.Color.Format.ShortHEX:
        case WI.Color.Format.HEXAlpha:
        case WI.Color.Format.ShortHEXAlpha:
        case WI.Color.Format.Keyword:
            components = this._color.rgb.map((value) => Math.round(value));
            break;

        case WI.Color.Format.HSL:
        case WI.Color.Format.HSLA:
            components = this._color.hsl.map((value) => value.maxDecimals(2));
            break;

        case WI.Color.Format.ColorFunction:
            components = this._color.normalizedRGB.map((value) => value.maxDecimals(4));
            break;

        default:
            console.error(`Unknown color format: ${this._color.format}`);
        }

        if (this._color.alpha !== 1 || this._needsAlphaColorInput())
            components.push(this._color.alpha);

        console.assert(this._colorInputs.length === components.length);
        for (let i = 0; i < components.length; ++i)
            this._colorInputs[i].value = components[i];
    }

    _handleColorInputsContainerInput(event)
    {
        let components = this._colorInputs.map((input) => {
            return isNaN(input.valueAsNumber) ? 0 : input.valueAsNumber;
        });
        this.color = new WI.Color(this._color.format, components, this._color.gamut);
        this.dispatchEventToListeners(WI.ColorPicker.Event.ColorChanged, {color: this._color});
    }

    _updateColorForVariable(resolvedColor, variableName)
    {
        this.color = resolvedColor;
        this.dispatchEventToListeners(WI.ColorPicker.Event.ColorChanged, {color: this._color, variableName});
    }

    _changeFormat(format)
    {
        if (this._color.format === format)
            return;

        this._color.format = format;
        this._colorInputsFormat = null;
        this._showColorComponentInputs();
        this.dispatchEventToListeners(WI.ColorPicker.Event.ColorChanged, {color: this._color});
    }

    _populateFormatContextMenu(contextMenu)
    {
        WI.ColorPicker.addContextMenuFormatItems(contextMenu, this._color, (format) => {
            this._changeFormat(format);
        });

        if (this._color.gamut !== WI.Color.Gamut.DisplayP3) {
            contextMenu.appendItem(WI.UIString("Convert to Display-P3"), () => {
                this._color.gamut = WI.Color.Gamut.DisplayP3;
                this._colorInputsFormat = null;
                this._showColorComponentInputs();
                this._updateColorGamut();
                this.dispatchEventToListeners(WI.ColorPicker.Event.ColorChanged, {color: this._color});
            });
        }

        if (this._color.gamut !== WI.Color.Gamut.SRGB) {
            let label = this._color.isOutsideSRGB() ? WI.UIString("Clamp to sRGB") : WI.UIString("Convert to sRGB");
            contextMenu.appendItem(label, () => {
                this._color.gamut = WI.Color.Gamut.SRGB;
                this._colorInputsFormat = null;
                this._showColorComponentInputs();
                this._updateColorGamut();
                this.dispatchEventToListeners(WI.ColorPicker.Event.ColorChanged, {color: this._color});
            });
        }
    }

    _createContrastInfoSection()
    {
        this._contrastInfoElement = this._element.appendChild(document.createElement("div"));
        this._contrastInfoElement.classList.add("contrast-info");

        let labelElement = this._contrastInfoElement.appendChild(document.createElement("span"));
        labelElement.classList.add("contrast-label");
        labelElement.textContent = WI.UIString("Contrast", "Contrast @ Color Picker", "Label for contrast ratio section in Color Picker");

        this._contrastRatioElement = this._contrastInfoElement.appendChild(document.createElement("span"));
        this._contrastRatioElement.classList.add("contrast-ratio");

        this._complianceBadgeElement = this._contrastInfoElement.appendChild(document.createElement("span"));
        this._complianceBadgeElement.classList.add("compliance-badge");

        let separatorElement = this._contrastInfoElement.appendChild(document.createElement("span"));
        separatorElement.classList.add("contrast-separator");
        separatorElement.textContent = WI.UIString("vs", "vs @ Color Picker Contrast", "Separator between foreground and background colors in contrast info");

        let swatchTooltip = this._contrastInfo.isBackgroundColor ? WI.UIString("Text Color") : WI.UIString("Background Color");
        let contrastSwatch = new WI.InlineSwatch(WI.InlineSwatch.Type.Color, this._contrastInfo.contrastColor, {readOnly: true, tooltip: swatchTooltip});
        this._contrastInfoElement.appendChild(contrastSwatch.element);
    }

    _updateContrastInfo()
    {
        if (!this._contrastInfo?.contrastColor || !this._contrastInfoElement)
            return;

        let effectiveForeground = this._color.blendOverBackground(this._contrastInfo.contrastColor);

        let ratio = effectiveForeground.contrastRatio(this._contrastInfo.contrastColor);
        let isLargeText = !!this._contrastInfo.isLargeText;
        let compliance = WI.Color.contrastComplianceForRatio(ratio, {isLargeText});

        this._contrastRatioElement.textContent = ratio.toFixed(2) + ":1";

        this._complianceBadgeElement.textContent = compliance;
        this._complianceBadgeElement.className = "compliance-badge";
        switch (compliance) {
        case WI.Color.ContrastCompliance.AAA:
            this._complianceBadgeElement.classList.add("contrast-aaa");
            break;
        case WI.Color.ContrastCompliance.AA:
            this._complianceBadgeElement.classList.add("contrast-aa");
            break;
        case WI.Color.ContrastCompliance.Fail:
            this._complianceBadgeElement.classList.add("contrast-fail");
            break;
        }
    }
};

WI.ColorPicker.Event = {
    ColorChanged: "css-color-picker-color-changed",
};
