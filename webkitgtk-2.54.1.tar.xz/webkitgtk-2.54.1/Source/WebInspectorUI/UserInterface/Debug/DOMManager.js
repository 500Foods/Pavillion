/*
 * Copyright (C) 2022 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. AND ITS CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL APPLE INC. OR ITS CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

Object.defineProperty(WI.DOMManager.prototype, "boundNodesDebugDescription", {
    get() {
        let debugDescription = "";
        function appendLine(line) {
            debugDescription += line + "\n";
        }

        const singleLevelSpacePrefix = "    ";
        function appendChildren(parent, level) {
            let spacePrefix = singleLevelSpacePrefix.repeat(level + 1);

            for (let child of parent.children) {
                appendLine(`${spacePrefix}id(${child.id}) displayName(${child.displayName})`);

                for (let pseudoElement of child.pseudoElements().values())
                    appendLine(`${spacePrefix}${singleLevelSpacePrefix}id(${pseudoElement.id}) displayName(${pseudoElement.displayName})`);

                if (child.children)
                    appendChildren(child, level + 1);
            }
        }

        let rootNodes = Object.values(this._idToDOMNode).filter((value) => !value.parentNode);
        for (let rootNode of rootNodes) {
            appendLine(`<${rootNode === this._document ? "Document" : "Detached"} Root> id(${rootNode.id}) displayName(${rootNode.displayName})`);
            if (rootNode.children)
                appendChildren(rootNode, 0);
        }

        return debugDescription;
    }
});